-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : ewshop_demo
-- 
-- Part : #1
-- Date : 2016-08-11 11:01:47
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `ewshop_action`
-- -----------------------------
DROP TABLE IF EXISTS `ewshop_action`;
CREATE TABLE `ewshop_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text COMMENT '行为规则',
  `log` text COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `ewshop_action`
-- -----------------------------
INSERT INTO `ewshop_action` VALUES ('1', 'user_login', '用户登录', '后台管理员登陆', '', '[admin|get_admin]在[time|time_format]登录了后台', '1', '1', '1462347622');
INSERT INTO `ewshop_action` VALUES ('2', 'add_article', '发布文章', '管理员发布文章', '', '[admin|get_admin]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '1', '1', '1462347668');
INSERT INTO `ewshop_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '-1', '1383285646');
INSERT INTO `ewshop_action` VALUES ('4', 'add_document', '发布产品', '管理员发布产品', '', '[admin|get_admin]在[time|time_format]发表了一个产品。\r\n表[model]，记录编号[record]。', '1', '1', '1462347719');
INSERT INTO `ewshop_action` VALUES ('12', 'update_Ad', '更新广告图片', '更新广告图片', '', '', '1', '1', '1460373748');
INSERT INTO `ewshop_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '-1', '1383285551');
INSERT INTO `ewshop_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `ewshop_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `ewshop_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `ewshop_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `ewshop_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `ewshop_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');
INSERT INTO `ewshop_action` VALUES ('13', 'update_Admin', '更新管理员', '更新管理员信息', '', '', '1', '1', '1460374774');
